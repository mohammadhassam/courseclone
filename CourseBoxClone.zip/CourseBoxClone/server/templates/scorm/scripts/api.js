/*
 * SCORM 2004 API Implementation with Interactive Features Support
 */

// Global API object
var API_1484_11 = null;

function initializeAPI() {
  console.log("Initializing SCORM 2004 API with interactive features");

  if (!API_1484_11) {
    API_1484_11 = new SCORM2004API();
  }

  window.API_1484_11 = API_1484_11;
  window.API = API_1484_11;

  return API_1484_11;
}

function SCORM2004API() {
  this.initialized = false;
  this.terminated = false;
  this.lastError = "0";

  // Enhanced data model to support interactive features
  this.dataModel = {
    "cmi._version": "1.0",
    "cmi.completion_status": "incomplete",
    "cmi.success_status": "unknown",
    "cmi.score.scaled": "0",
    "cmi.score.raw": "0",
    "cmi.score.min": "0",
    "cmi.score.max": "100",
    "cmi.interactions": [],
    "cmi.learner_response": "",
    "adl.nav.request": ""
  };

  // Initialize API
  this.Initialize = function(parameter) {
    if (parameter !== "") {
      this.lastError = "201";
      return "false";
    }
    if (this.initialized) {
      this.lastError = "103";
      return "false";
    }

    this.initialized = true;
    this.terminated = false;
    this.lastError = "0";

    // Initialize interactive elements
    this.initializeInteractiveElements();

    return "true";
  };

  // Handle interactive elements initialization
  this.initializeInteractiveElements = function() {
    document.addEventListener('DOMContentLoaded', () => {
      const quizzes = document.querySelectorAll('.quiz-container');
      quizzes.forEach((quiz, index) => {
        this.setupQuizHandlers(quiz, index);
      });

      const exercises = document.querySelectorAll('.interactive-exercise');
      exercises.forEach((exercise, index) => {
        this.setupExerciseHandlers(exercise, index);
      });
    });
  };

  // Setup quiz interaction handlers
  this.setupQuizHandlers = function(quiz, index) {
    const submitButton = quiz.querySelector('.submit-quiz');
    if (submitButton) {
      submitButton.addEventListener('click', () => {
        const answers = quiz.querySelectorAll('input:checked');
        const score = this.calculateQuizScore(answers);
        this.recordInteraction('quiz', index, score);
      });
    }
  };

  // Setup exercise interaction handlers
  this.setupExerciseHandlers = function(exercise, index) {
    const submitButton = exercise.querySelector('.submit-exercise');
    if (submitButton) {
      submitButton.addEventListener('click', () => {
        const response = exercise.querySelector('.exercise-input').value;
        this.recordInteraction('exercise', index, response);
      });
    }
  };

  // Record interaction in SCORM data model
  this.recordInteraction = function(type, index, response) {
    const interaction = {
      id: `${type}_${index}`,
      type: type,
      timestamp: new Date().toISOString(),
      response: response
    };

    this.dataModel.cmi.interactions.push(interaction);
    this.SetValue("cmi.interactions._count", this.dataModel.cmi.interactions.length);
    this.Commit("");
  };

  // Calculate quiz score
  this.calculateQuizScore = function(answers) {
    // Implement scoring logic
    return (answers.length / this.totalQuestions) * 100;
  };

  // Get Value implementation
  this.GetValue = function(element) {
    if (!this.initialized) {
      this.lastError = "122";
      return "";
    }

    if (this.terminated) {
      this.lastError = "123";
      return "";
    }

    // Handle nested properties
    const path = element.split('.');
    let value = this.dataModel;
    for (let i = 0; i < path.length; i++) {
      if (value[path[i]] === undefined) {
        this.lastError = "401";
        return "";
      }
      value = value[path[i]];
    }

    this.lastError = "0";
    return String(value);
  };

  // Set Value implementation
  this.SetValue = function(element, value) {
    if (!this.initialized) {
      this.lastError = "132";
      return "false";
    }

    if (this.terminated) {
      this.lastError = "133";
      return "false";
    }

    // Handle nested properties
    const path = element.split('.');
    let target = this.dataModel;
    for (let i = 0; i < path.length - 1; i++) {
      if (target[path[i]] === undefined) {
        target[path[i]] = {};
      }
      target = target[path[i]];
    }

    target[path[path.length - 1]] = value;
    this.lastError = "0";
    return "true";
  };

  // Commit changes
  this.Commit = function(parameter) {
    if (!this.initialized) {
      this.lastError = "142";
      return "false";
    }

    this.lastError = "0";
    return "true";
  };

  // Terminate session
  this.Terminate = function(parameter) {
    if (!this.initialized) {
      this.lastError = "112";
      return "false";
    }

    this.Commit("");
    this.initialized = false;
    this.terminated = true;

    return "true";
  };

  // Error handling
  this.GetLastError = function() {
    return this.lastError;
  };

  this.GetErrorString = function(errorCode) {
    // Add error strings as needed
    return "Error occurred";
  };

  this.GetDiagnostic = function(errorCode) {
    return "Diagnostic information";
  };
}

// Helper function to display SCORM status and interactive elements
function displaySCORMStatus() {
  const statusDiv = document.getElementById('scorm-status') || createStatusDiv();

  const api = window.API_1484_11 || window.API;
  if (api) {
    const status = `
      Completion Status: ${api.GetValue("cmi.completion_status")} | 
      Success Status: ${api.GetValue("cmi.success_status")} | 
      Score: ${api.GetValue("cmi.score.scaled")} | 
      Interactions: ${api.GetValue("cmi.interactions._count")}
    `;
    statusDiv.textContent = status;
  } else {
    statusDiv.textContent = "SCORM API not initialized";
  }
}

function createStatusDiv() {
  const div = document.createElement('div');
  div.id = 'scorm-status';
  document.body.insertBefore(div, document.body.firstChild);
  return div;
}

// Update status periodically
window.setInterval(function() {
  if (window.API_1484_11 || window.API) {
    displaySCORMStatus();
  }
}, 2000);