/*
 * TinCan (xAPI) API Implementation
 * 
 * This is a simplified xAPI interface for demonstration purposes
 * In a production environment, you would use the TinCanJS library
 */

// TinCan API Implementation
function TinCan(options) {
  // Store the configuration options
  this.config = options || {};
  
  // Store statements that will be sent to LRS
  this.statements = [];
  
  // Default actor (learner)
  this.actor = {
    objectType: "Agent",
    name: "Unknown Learner",
    mbox: "mailto:learner@example.com"
  };
  
  // Initialize the TinCan API
  this.init();
}

// TinCan Prototype
TinCan.prototype = {
  // Initialize the TinCan API
  init: function() {
    console.log("TinCan API initialized with:", this.config);
    
    // Try to get the learner info from URL query parameters or localStorage
    try {
      var urlParams = new URLSearchParams(window.location.search);
      if (urlParams.has('actor')) {
        this.actor = JSON.parse(decodeURIComponent(urlParams.get('actor')));
      } else if (localStorage.getItem('tincan_actor')) {
        this.actor = JSON.parse(localStorage.getItem('tincan_actor'));
      }
    } catch (e) {
      console.error("Error initializing TinCan actor:", e);
    }
  },
  
  // Send a statement to the LRS
  sendStatement: function(statement) {
    // Ensure statement has required properties
    if (!statement.verb) {
      console.error("Statement missing required verb property");
      return false;
    }
    
    if (!statement.object) {
      console.error("Statement missing required object property");
      return false;
    }
    
    // Add default properties
    var fullStatement = {
      actor: this.actor,
      verb: statement.verb,
      object: statement.object,
      result: statement.result || null,
      context: statement.context || null,
      timestamp: new Date().toISOString()
    };
    
    console.log("Sending xAPI statement:", fullStatement);
    
    // In a real implementation, this would send the statement to an LRS
    // For this demo, we'll just store it and save to localStorage
    this.statements.push(fullStatement);
    try {
      localStorage.setItem('tincan_statements', JSON.stringify(this.statements));
    } catch (e) {
      console.error("Failed to save statements to localStorage:", e);
    }
    
    return true;
  },
  
  // Retrieve stored statements
  getStatements: function() {
    return this.statements;
  },
  
  // Set the activity's completion status
  setComplete: function(activityId) {
    return this.sendStatement({
      verb: {
        id: "http://adlnet.gov/expapi/verbs/completed",
        display: { "en-US": "completed" }
      },
      object: {
        id: activityId || this.config.activity.id,
        definition: this.config.activity.definition
      },
      result: {
        completion: true,
        success: true
      }
    });
  }
};

// Helper function to initialize TinCan with activity ID information from links
document.addEventListener('DOMContentLoaded', function() {
  // Find all links with tincan-activity class and add event listeners
  var tincanLinks = document.querySelectorAll('.tincan-activity');
  
  tincanLinks.forEach(function(link) {
    link.addEventListener('click', function(e) {
      // Don't add event listener if there's no activity ID
      if (!this.dataset.activityId) return;
      
      // Create TinCan instance for this activity
      var tincan = new TinCan({
        activity: {
          id: this.dataset.activityId,
          definition: {
            name: { "en-US": this.textContent.trim() }
          }
        }
      });
      
      // Send launched statement
      tincan.sendStatement({
        verb: {
          id: "http://adlnet.gov/expapi/verbs/launched",
          display: { "en-US": "launched" }
        },
        object: {
          id: this.dataset.activityId
        }
      });
      
      // Continue with normal link behavior
    });
  });
});