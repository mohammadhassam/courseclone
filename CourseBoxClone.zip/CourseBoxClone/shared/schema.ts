import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Interactive content types
export const interactiveContentTypes = ["tabs", "dragDrop", "quiz", "html"] as const;
export type InteractiveContentType = typeof interactiveContentTypes[number];

// Question types for quizzes
export const questionTypes = ["multipleChoice", "trueFalse", "shortAnswer", "matching", "fillInBlank"] as const;
export type QuestionType = typeof questionTypes[number];

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name"),
  email: text("email"),
  role: text("role").default("student").notNull(), // student, instructor, admin
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
  email: true,
  role: true,
});

export const userRoles = ["student", "instructor", "admin"] as const;
export type UserRole = typeof userRoles[number];

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Course model
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("draft"), // draft, published
  coverImage: text("cover_image"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;

// Module model (section of a course)
export const modules = pgTable("modules", {
  id: serial("id").primaryKey(),
  courseId: integer("course_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  order: integer("order").notNull(),
});

export const insertModuleSchema = createInsertSchema(modules).omit({
  id: true,
});

export type InsertModule = z.infer<typeof insertModuleSchema>;
export type Module = typeof modules.$inferSelect;

// Bloom's Taxonomy levels for defining learning objectives
export const bloomsTaxonomyLevels = ["remember", "understand", "apply", "analyze", "evaluate", "create"] as const;
export type BloomsTaxonomyLevel = typeof bloomsTaxonomyLevels[number];

// Lesson model (content within a module)
export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  moduleId: integer("module_id").notNull(),
  title: text("title").notNull(),
  content: text("content"),
  order: integer("order").notNull(),
  duration: integer("duration"), // in minutes
  taxonomyLevel: text("taxonomy_level").default("remember"), // Bloom's Taxonomy level
});

export const insertLessonSchema = createInsertSchema(lessons).omit({
  id: true,
});

export type InsertLesson = z.infer<typeof insertLessonSchema>;
export type Lesson = typeof lessons.$inferSelect;

// Course creation types
export const courseCreationSteps = ["info", "outline", "content", "publish"] as const;
export type CourseCreationStep = typeof courseCreationSteps[number];

// CourseOutline captures full course structure for creation/editing
export type CourseOutline = {
  course: {
    title: string;
    description: string;
    coverImage?: string;
  };
  modules: {
    id?: number;
    title: string;
    description?: string;
    order: number;
    lessons: {
      id?: number;
      title: string;
      content?: string;
      order: number;
      duration?: number;
      taxonomyLevel?: BloomsTaxonomyLevel;
    }[];
  }[];
};

export type CourseWithModulesAndLessons = Course & {
  modules: (Module & {
    lessons: Lesson[];
  })[];
};

// Quiz types
export type QuizQuestion = {
  id?: string;
  type: QuestionType;
  question: string;
  options?: string[];
  correctAnswer: string | string[];
  feedback?: string;
  points?: number;
};

export type Quiz = {
  id?: string;
  type: "quiz";
  title: string;
  description?: string;
  questions: QuizQuestion[];
  passingScore?: number;
  shuffleQuestions?: boolean;
};

// Tab content type for interactive tab components
export type TabContent = {
  title: string;
  content: string;
};

export type TabsInteractive = {
  type: "tabs";
  tabs: TabContent[];
};

// Drag and drop content type
export type DragDropItem = {
  id: string;
  content: string;
  correctZone: string;
};

export type DropZone = {
  id: string;
  title: string;
};

export type DragDropInteractive = {
  type: "dragDrop";
  instructions: string;
  items: DragDropItem[];
  zones: DropZone[];
};

// Interactive content union type
export type InteractiveContent = TabsInteractive | DragDropInteractive | Quiz;

// Update Lesson type to include interactive elements
export type LessonContent = {
  html?: string;
  interactiveElements?: InteractiveContent[];
};

// Enrollment status
export const enrollmentStatuses = ["enrolled", "completed", "in_progress", "dropped"] as const;
export type EnrollmentStatus = typeof enrollmentStatuses[number];

// Enrollment model
export const enrollments = pgTable("enrollments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  courseId: integer("course_id").notNull(),
  status: text("status").default("enrolled").notNull(),
  enrolledAt: timestamp("enrolled_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  lastAccessedAt: timestamp("last_accessed_at").defaultNow().notNull(),
  progress: integer("progress").default(0).notNull(), // percentage 0-100
});

export const insertEnrollmentSchema = createInsertSchema(enrollments).omit({
  id: true,
  enrolledAt: true,
  completedAt: true,
  lastAccessedAt: true,
});

export type InsertEnrollment = z.infer<typeof insertEnrollmentSchema>;
export type Enrollment = typeof enrollments.$inferSelect;

// Type for course with enrollment information
export type CourseWithEnrollment = Course & {
  isEnrolled?: boolean;
  enrollment?: Enrollment;
};
